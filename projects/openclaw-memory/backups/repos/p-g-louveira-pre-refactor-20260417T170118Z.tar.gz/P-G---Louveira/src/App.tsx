import { 
  ReportHeader, 
  DashboardCards, 
  ProgressRow, 
  TaskList, 
  RiskHeatmap, 
  ActionPlan, 
  LookAhead, 
  WeeklyComparison 
} from "./components/ReportComponents";
import { AlertCircle, FileSearch, Lightbulb, TrendingUp, TrendingDown, Clock3 } from "lucide-react";
import { motion } from "motion/react";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-100 pb-20 print:bg-white print:pb-0">
      <ReportHeader />
      
      <main className="max-w-[1400px] mx-auto px-4 md:px-8 -mt-6">
        <DashboardCards />
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column (8 units) */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Weekly Diagnosis */}
            <section className="section-card">
              <h2 className="text-base font-black flex items-center gap-2 mb-4 text-slate-800 uppercase tracking-widest">
                <FileSearch className="text-mensura-blue w-5 h-5" /> Diagnóstico Geral
              </h2>
              <div className="space-y-4 text-[13px] leading-relaxed text-slate-600 font-medium text-justify">
                <p>
                  A obra P&G encontra-se com <strong className="text-mensura-dark">45,49% de avanço físico executado</strong> contra <strong className="text-mensura-dark">81,03% previsto</strong>, resultando em desvio de <strong className="text-mensura-red">-35,54 pontos percentuais</strong> e SPI de 0,56. O gap abriu 4 pp em relação à semana anterior. A paralisação de 64 dias por indefinição do projeto de ar-condicionado é a causa raiz documentada do desvio acumulado.
                </p>
                <div className="bg-red-50 p-4 rounded-xl border border-red-100 border-l-4 border-l-mensura-red">
                  <span className="text-[10px] font-black uppercase text-mensura-red tracking-widest block mb-1">Indicador Crítico</span>
                  <p className="text-mensura-red font-bold">O BEI de 0,42 é o indicador mais alarmante: das 562 atividades que deveriam estar concluídas até a data-base, apenas 234 estão (45%).</p>
                </div>
                <p>
                  A retomada pós-paralisação 64 dias exige que bloqueios críticos como o PO da Pele de Vidro e o Contrato CK sejam resolvidos imediatamente. O feriado é a janela estratégica para atividades ruidosas e em altura.
                </p>
              </div>
            </section>

            <WeeklyComparison />

            {/* Progress Section */}
            <section className="section-card">
              <h2 className="text-base font-black flex items-center gap-2 mb-6 text-slate-800 uppercase tracking-widest">
                <TrendingUp className="text-mensura-green w-5 h-5" /> Avanço por Área
              </h2>
              <ProgressRow label="OBRA GERAL" current={45.49} target={81.03} prevLabel="Erava 42,2%" />
              <ProgressRow label="Estrutura Metálica" current={99} target={100} prevLabel="+2pp" />
              <ProgressRow label="Lab. Sensorial — Térreo" current={59} target={90} prevLabel="Rebase" />
              <ProgressRow label="Lab. Sensorial — 1º Pav." current={61} target={85} prevLabel="Estável" />
              <ProgressRow label="Terraço" current={62} target={85} prevLabel="+2pp" />
            </section>

            <LookAhead />

            {/* Baseline 1 Detailed Analysis */}
            <section className="section-card">
               <h2 className="text-base font-black flex items-center gap-2 mb-6 text-slate-800 uppercase tracking-widest">
                <Clock3 className="text-mensura-orange w-5 h-5" /> Metas Semanais (Baseline 1)
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <TaskList title="TÉRREO — NÃO CUMPRIDAS" tasks={[
                  { pct: '0%', name: 'Desligamento do SDAI', date: '13/04' },
                  { pct: '60%', name: 'Execução ponto esgoto', date: '15/04' },
                  { pct: '54%', name: 'Conduletes elétrica parede', date: '14/04' },
                  { pct: '95%', name: 'Revisão infra SPK', date: '12/04' }
                ]} />
                <TaskList title="1º PAV — NÃO CUMPRIDAS" tasks={[
                  { pct: '0%', name: 'Desligamento do SDAI', date: '14/04' },
                  { pct: '80%', name: 'Abertura vãos laje', date: '12/04' },
                  { pct: '85%', name: 'Estrutura drywall', date: '07/04' },
                  { pct: '50%', name: 'Execução ponto água', date: '14/04' }
                ]} />
              </div>
            </section>
          </div>

          {/* Right Column (4 units) */}
          <div className="lg:col-span-4 space-y-6">
            
            <ActionPlan />
            
            <RiskHeatmap />

            {/* Predictive Analysis Box */}
            <section className="bg-mensura-darker text-white p-6 rounded-2xl shadow-xl border border-white/5">
              <h2 className="text-sm font-black uppercase tracking-widest mb-6 flex items-center gap-2">
                <TrendingUp className="text-mensura-blue w-4 h-4" /> Análise Preditiva
              </h2>
              
              <div className="space-y-4">
                <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] font-black text-mensura-blue uppercase tracking-widest">Provável (65%)</span>
                    <span className="text-xs font-mono font-bold">01/08/2026</span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-medium leading-relaxed">Considera manutenção do ritmo atual (SPI 0,56) e fornecedores respondendo parcialmente.</p>
                </div>

                <div className="p-4 bg-white/5 rounded-xl border-l-4 border-l-mensura-red border-y border-r border-white/5">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] font-black text-mensura-red uppercase tracking-widest">Pessimista (25%)</span>
                    <span className="text-xs font-mono font-bold">30/09/2026</span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-medium leading-relaxed">Ocorre se CK não fechar contrato e Airtime não duplicar equipes pós-feriado.</p>
                </div>
              </div>
            </section>

            {/* Management Directives */}
            <section className="section-card border-2 border-mensura-dark">
              <h2 className="text-base font-black flex items-center gap-2 mb-6 text-slate-800 uppercase tracking-widest">
                <Lightbulb className="text-mensura-yellow w-5 h-5" /> Diretrizes
              </h2>
              <ul className="space-y-4">
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-mensura-red mt-1.5 flex-shrink-0" />
                  <p className="text-xs font-bold text-slate-600">Zero tolerância para atividades acima de 85% sem fechamento em 48h.</p>
                </li>
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-mensura-blue mt-1.5 flex-shrink-0" />
                  <p className="text-xs font-bold text-slate-600">Maximizar feriado para atividades ruidosas e em altura.</p>
                </li>
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-mensura-orange mt-1.5 flex-shrink-0" />
                  <p className="text-xs font-bold text-slate-600">Escalar JLL sobre PO Pele de Vidro IMEDIATAMENTE.</p>
                </li>
              </ul>
            </section>
          </div>

        </div>

        {/* Footer info */}
        <footer className="mt-12 text-center pb-12 border-t border-slate-200 pt-8">
            <p className="text-[10px] uppercase tracking-widest font-black text-slate-400 mb-2">SISTEMA MENSURA — ENGENHARIA DE GESTÃO</p>
            <div className="flex justify-center gap-4 text-[9px] font-bold text-slate-500 uppercase">
                <span>Relatório Nº 002</span>
                <span>•</span>
                <span>Data: 16/04/2026</span>
                <span>•</span>
                <span>Status da Obra: CRÍTICO</span>
            </div>
        </footer>
      </main>
    </div>
  );
}
