import React from "react";
import { TrendingUp, TrendingDown, AlertCircle, CheckCircle2, Clock, CalendarDays, Maximize2, ShieldAlert, ListTodo, Users, Construction, GanttChartSquare, ClipboardList, Activity, ArrowRightLeft } from "lucide-react";
import { motion } from "motion/react";

// --- Header Component ---
export const ReportHeader = () => (
  <header className="bg-mensura-dark bg-gradient-to-br from-mensura-dark to-mensura-darker text-white p-6 md:p-8 shadow-lg print:bg-mensura-dark print:text-white">
    <div className="max-w-[1400px] mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">SISTEMA MENSURA — Relatório Executivo</h1>
          <p className="text-slate-400 mt-1 font-medium text-xs md:text-sm">Projeto P&G — Laboratório Sensorial | Louveira-SP | Construtora: SUM Engenharia</p>
        </div>
        <div className="text-right hidden md:block">
            <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Relatório Nº 002</span>
            <p className="text-xl font-mono font-bold text-mensura-blue">16/04/2026</p>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-2 mt-6 text-[10px] md:text-xs">
        <span className="bg-white/10 px-3 py-1.5 rounded-lg flex items-center gap-2 border border-white/5">
          <CalendarDays className="w-3 h-3 text-mensura-blue" /> Status: 15/04/2026
        </span>
        <span className="bg-white/10 px-3 py-1.5 rounded-lg border border-white/5">📋 Emissão: 16/04/2026</span>
        <span className="bg-white/10 px-3 py-1.5 rounded-lg border border-white/5 flex items-center gap-2">
          <Clock className="w-3 h-3 text-mensura-orange" /> Término Meta: 05/07/2026
        </span>
        <span className="bg-mensura-orange/20 text-mensura-orange border border-mensura-orange/30 px-3 py-1.5 rounded-lg font-bold">⏱️ 80 Dias Restantes</span>
      </div>
      
      <div className="mt-6 flex flex-wrap items-center gap-x-8 gap-y-4 text-xs font-semibold border-t border-white/10 pt-4">
        <div className="flex flex-col">
            <span className="text-slate-500 uppercase text-[9px] tracking-widest mb-1">Avanço Previsto</span>
            <span className="text-mensura-blue text-sm">81,03%</span>
        </div>
        <div className="flex flex-col">
            <span className="text-slate-500 uppercase text-[9px] tracking-widest mb-1">Avanço Executado</span>
            <span className="text-mensura-red text-sm">45,49%</span>
        </div>
        <div className="flex flex-col border-l border-white/10 pl-8">
            <span className="text-slate-500 uppercase text-[9px] tracking-widest mb-1">Desvio Acumulado</span>
            <span className="text-mensura-red text-sm font-bold">-35,54 pp</span>
        </div>
      </div>
    </div>
  </header>
);

// --- Dashboard Component ---
export const DashboardCards = () => {
  const cards = [
    { label: "Executado", value: "45,49%", detail: "Previsto: 81,03%", delta: "↑ +3,29 pp vs sem. ant.", color: "red" },
    { label: "Lab. Sensorial", value: "63%", detail: "Meta Revisada", delta: "↓ Rebase atividades", color: "red" },
    { label: "Tarefas pendentes", value: "395", detail: "De 681 totais", delta: "↑ +243 (Rebase)", color: "red" },
    { label: "Caminho Crítico", value: "25", detail: "Itens < 100%", delta: "↑ +2 vs sem. ant.", color: "red" },
    { label: "SPI", value: "0,56", detail: "Ritmo de Obra", delta: "↓ -0,01 vs sem. ant.", color: "red" },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
      {cards.map((card, idx) => (
        <motion.div 
          key={idx}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: idx * 0.05 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-slate-200 border-l-4 border-l-mensura-red flex flex-col"
        >
          <span className="text-[9px] uppercase tracking-widest text-slate-400 font-black mb-2">{card.label}</span>
          <span className="text-2xl font-black text-mensura-red my-0.5 font-mono">{card.value}</span>
          <span className="text-[10px] text-slate-500 font-medium">{card.detail}</span>
          <span className={`text-[9px] font-bold mt-2 flex items-center gap-1 ${card.delta.includes('↑') ? 'text-green-600' : 'text-red-500'}`}>
            {card.delta}
          </span>
        </motion.div>
      ))}
    </div>
  );
};

// --- Progress Row Component ---
export const ProgressRow = ({ label, current, target, prevLabel }: { label: string, current: number, target: number, prevLabel?: string }) => {
  return (
    <div className="mb-5">
      <div className="flex justify-between items-end mb-1.5">
        <span className="text-[11px] font-black uppercase tracking-tight text-slate-700">{label}</span>
        <div className="text-[9px] font-mono font-bold tracking-tighter">
          <span className="text-mensura-blue bg-blue-50 px-1.5 py-0.5 rounded">PREV: {target}%</span>
          <span className="mx-1.5 text-slate-300">|</span>
          <span className="text-mensura-red bg-red-50 px-1.5 py-0.5 rounded">REAL: {current}%</span>
          {prevLabel && <span className="ml-2 text-slate-400 italic font-normal">{prevLabel}</span>}
        </div>
      </div>
      <div className="h-5 w-full bg-slate-100 rounded-full overflow-hidden relative shadow-inner border border-slate-200">
        <div 
          className="absolute top-0 h-full border-r-2 border-slate-800/20 border-dashed z-10" 
          style={{ width: `${target}%` }}
        ></div>
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${current}%` }}
          className={`h-full flex items-center justify-end px-3 text-[9px] font-black text-white shadow-sm shadow-black/10 transition-all ${current >= target ? 'bg-mensura-green' : 'bg-mensura-red'}`}
        >
          {current < 10 ? '' : `${current}%`}
        </motion.div>
      </div>
    </div>
  );
};

// --- Task List Component ---
export const TaskList = ({ title, tasks }: { title: string, tasks: any[] }) => (
  <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-100">
    <h3 className="text-[11px] font-black text-slate-800 border-b border-slate-200 pb-2 mb-3 uppercase tracking-widest flex items-center gap-2">
        <ClipboardList className="w-3 h-3 text-mensura-blue" /> {title}
    </h3>
    <div className="space-y-1.5">
      {tasks.map((task, idx) => (
        <div key={idx} className="flex items-center gap-2 px-2 py-1.5 hover:bg-white hover:shadow-sm rounded-lg transition-all border border-transparent hover:border-slate-100 group">
          <span className={`text-[9px] font-black w-9 text-center py-0.5 rounded-md border flex-shrink-0 ${task.pct === '0%' ? 'bg-red-50 text-red-700 border-red-100' : 'bg-orange-50 text-orange-700 border-orange-100'}`}>
            {task.pct}
          </span>
          <span className="text-[11px] flex-grow text-slate-700 font-bold leading-tight group-hover:text-mensura-dark">{task.name}</span>
          <span className="text-[9px] font-black text-slate-400 whitespace-nowrap bg-slate-100 px-1.5 py-0.5 rounded uppercase font-mono">{task.date}</span>
        </div>
      ))}
    </div>
  </div>
);

// --- Risk Heatmap ---
export const RiskHeatmap = () => {
  const [selected, setSelected] = React.useState<null|{id:string,cat:string,title:string,p:number,i:number,score:number,status:string,deadline:string,desc:string}>(null);

  const risks = [
    { id:'R01', cat:'RISCO CRÍTICO — CAMINHO CRÍTICO', title:'Pele de vidro — PO não aprovado + cantoneiras', p:5, i:5, score:25, status:'blocked', deadline:'Imediato', desc:'PO não assinado pela P&G. Impacta entregas críticas de cantoneiras e pele de vidro. Risco de paralisação total do pacote.' },
    { id:'R02', cat:'FORNECEDOR CRÍTICO — HIDRÁULICA/SPK', title:'IZIKON — atrasos crônicos hidráulica/SPK', p:4, i:5, score:20, status:'blocked', deadline:'18/04', desc:'Atrasos recorrentes comprometem instalações críticas. Risco de impacto em datas de entrega do caminho crítico.' },
    { id:'R03', cat:'FORNECEDOR CRÍTICO — HVAC', title:'Airtime — equipe insuficiente + CSJSA com erros', p:4, i:5, score:20, status:'blocked', deadline:'21/04', desc:'Equipe subdimensionada. CSJSA com erros técnicos. Impacta HVAC e cronograma global.' },
    { id:'R11', cat:'RISCO NOVO — SEGURADORA/SDAI', title:'Desligamento SDAI — seguradora bloqueando', p:4, i:5, score:20, status:'blocked', deadline:'20/04', desc:'Seguradora bloqueando desligamento do SDAI. Impacta liberação de frentes de trabalho. Risco regulatório.' },
    { id:'R05', cat:'FORNECEDOR — DIVISÓRIAS HPL', title:'Divisórias HPL — 2ª sem. sem contrato CK', p:4, i:4, score:16, status:'blocked', deadline:'18/04', desc:'2ª semana consecutiva sem assinatura CK. Bloqueia fabricação e entrega das divisórias HPL.' },
    { id:'R06', cat:'FORNECEDOR — ESTRUTURA METÁLICA', title:'San Carlos — calhas, rufos, cantoneiras, escada marinheiro', p:4, i:4, score:16, status:'progress', deadline:'21/04', desc:'Calhas/rufos a 90% mas não entregues. Cantoneiras e escada marinheiro pendentes. Impacto direto em acabamentos.' },
    { id:'R07', cat:'GESTÃO — COMUNICAÇÃO', title:'Informações verbais / rádio engenheiro', p:3, i:5, score:15, status:'progress', deadline:'Imediato', desc:'Padrão de solicitações verbais sem registro. Decisões críticas via rádio sem documentação formal.' },
    { id:'R04', cat:'SERVIÇO ESPECIALIZADO', title:'Décio — reforço fibra carbono (0% — NÃO INICIADO)', p:3, i:4, score:12, status:'progress', deadline:'30/04', desc:'0% — pré-condição: conclusão do shaft. Sem início formal. Risco de cascata em estrutura.' },
    { id:'R08', cat:'FORNECEDOR — DADOS/VOZ/SDAI', title:'DroneTech — dados/voz com contrato mas sem início', p:4, i:3, score:12, status:'progress', deadline:'21/04', desc:'Contrato fechado, laudo entregue. Sem mobilização. Impacta infraestrutura de dados e voz.' },
    { id:'R09', cat:'FORNECEDOR — BANCADAS/GRANITOS', title:'NPS atrasada >30 dias — medição de bancadas', p:3, i:4, score:12, status:'blocked', deadline:'20/04', desc:'>30 dias de atraso. Bloqueia marcenaria e acabamentos de bancadas.' },
    { id:'R10', cat:'EXECUÇÃO — ACABAMENTOS', title:'Volume massivo de acabamentos a 0%', p:3, i:4, score:12, status:'blocked', deadline:'30/04', desc:'Quantidade crítica de acabamentos a 0%. BEI 0,42 reflete atraso sistêmico. Risco de prazo final.' },
  ];
  // Helper: get risks at a cell (p, i)
  const getRisksAt = (p: number, i: number) => risks.filter(r => r.p === p && r.i === i);

  // Score = p * i
  const getHeat = (p: number, i: number): 'critical'|'high'|'medium'|'low' => {
    const s = p * i;
    if (s >= 20) return 'critical';
    if (s >= 12) return 'high';
    if (s >= 6) return 'medium';
    return 'low';
  };

  const heatBg: Record<string,'critical'|'high'|'medium'|'low'> = {
    critical: 'critical', high: 'high', medium: 'medium', low: 'low'
  };

  const cellStyle = (heat: string): React.CSSProperties => {
    if (heat === 'critical') return { background:'rgba(192,57,43,0.12)', borderColor:'rgba(192,57,43,0.45)', color:'#c0392b' };
    if (heat === 'high')     return { background:'rgba(230,126,34,0.10)', borderColor:'rgba(230,126,34,0.40)', color:'#e67e22' };
    if (heat === 'medium')   return { background:'rgba(241,196,15,0.10)', borderColor:'rgba(241,196,15,0.40)', color:'#c9a800' };
    return { background:'rgba(39,174,96,0.08)', borderColor:'rgba(39,174,96,0.35)', color:'#27ae60' };
  };

  const badgeBg = (heat: string): React.CSSProperties => {
    if (heat === 'critical') return { background:'#c0392b', color:'#fff' };
    if (heat === 'high')     return { background:'#e67e22', color:'#fff' };
    if (heat === 'medium')   return { background:'#d4aa00', color:'#fff' };
    return { background:'#27ae60', color:'#fff' };
  };

  const statusColor: Record<string,string> = { blocked:'#c0392b', progress:'#e67e22', ok:'#27ae60' };
  const statusLabel: Record<string,string> = { blocked:'BLOQUEADO', progress:'EM ANDAMENTO', ok:'CONCLUÍDO' };

  const critCount = risks.filter(r => r.score >= 20).length;
  const totalExp = risks.reduce((acc, r) => acc + r.score, 0);
  const openCount = risks.filter(r => r.status !== 'ok').length;

  return (
    <section style={{ background:'#f0f2f5', borderRadius:10, padding:24, marginBottom:24, fontFamily:"'Segoe UI',sans-serif" }}>
      {/* HEADER */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20, borderBottom:'2px solid #2c3e50', paddingBottom:12 }}>
        <div>
          <p style={{ margin:0, fontSize:10, fontWeight:700, letterSpacing:3, color:'#7f8c8d', textTransform:'uppercase' }}>GESTÃO DE RISCOS · RELATÓRIO Nº 002 · 15.04.2026</p>
          <h2 style={{ margin:'4px 0 0', fontSize:20, fontWeight:700, color:'#1a1a2e', fontStyle:'italic', fontFamily:"'Georgia',serif" }}>Matriz de Risco — Probabilidade × Impacto</h2>
        </div>
        <div style={{ display:'flex', gap:12 }}>
          {[
            { lbl:'EXPOSIÇÃO TOTAL', val: String(totalExp), clr:'#2980b9' },
            { lbl:'CRÍTICOS', val: String(critCount), clr:'#c0392b' },
            { lbl:'EM ABERTO', val: String(openCount), clr:'#e67e22' },
          ].map(kpi => (
            <div key={kpi.lbl} style={{ textAlign:'center', background:'#fff', border:'1px solid #dde1e7', borderRadius:6, padding:'8px 16px', minWidth:80 }}>
              <div style={{ fontSize:22, fontWeight:300, color: kpi.clr, lineHeight:1 }}>{kpi.val}</div>
              <div style={{ fontSize:9, fontWeight:700, letterSpacing:1.5, color:'#7f8c8d', marginTop:3, textTransform:'uppercase' }}>{kpi.lbl}</div>
            </div>
          ))}
        </div>
      </div>

      {/* MAIN LAYOUT */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 260px', gap:20 }}>

        {/* MATRIX */}
        <div>
          {/* Y-axis label */}
          <div style={{ display:'flex', alignItems:'stretch', gap:4 }}>
            {/* Y label */}
            <div style={{ display:'flex', alignItems:'center', justifyContent:'center', writingMode:'vertical-rl', transform:'rotate(180deg)', fontSize:10, fontWeight:700, letterSpacing:2, color:'#7f8c8d', textTransform:'uppercase', paddingRight:4 }}>IMPACTO</div>
            {/* Grid + X axis */}
            <div style={{ flex:1 }}>
              {/* 5x5 Grid — rows from I=5 (top) to I=1 (bottom) */}
              {[5,4,3,2,1].map(impVal => (
                <div key={impVal} style={{ display:'flex', alignItems:'stretch', gap:3, marginBottom:3 }}>
                  {/* Row label */}
                  <div style={{ width:22, display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:700, color:'#2c3e50', flexShrink:0 }}>{impVal}</div>
                  {/* Cells */}
                  {[1,2,3,4,5].map(probVal => {
                    const heat = getHeat(probVal, impVal);
                    const cs = cellStyle(heat);
                    const cellRisks = getRisksAt(probVal, impVal);
                    return (
                      <div
                        key={probVal}
                        style={{
                          flex:1, minHeight:72, border:'1.5px solid', ...cs,
                          display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                          gap:2, padding:3, cursor: cellRisks.length > 0 ? 'pointer' : 'default',
                          position:'relative', transition:'box-shadow 0.15s',
                        }}
                        title={`P${probVal} × I${impVal} = ${probVal*impVal}`}
                      >
                        {/* Score in corner */}
                        <span style={{ position:'absolute', top:3, right:4, fontSize:9, fontWeight:600, opacity:0.5, color:'inherit', fontFamily:"'Courier New',monospace" }}>{probVal*impVal}</span>
                        {/* Risk badges — all visible, no overlap */}
                        {cellRisks.map(r => (
                          <span
                            key={r.id}
                            onClick={() => setSelected(r)}
                            title={r.title}
                            style={{
                              ...badgeBg(heat),
                              fontSize:9, fontWeight:700, padding:'2px 5px',
                              borderRadius:3, cursor:'pointer', letterSpacing:0.5,
                              whiteSpace:'nowrap', fontFamily:"'Courier New',monospace",
                              boxShadow:'0 1px 3px rgba(0,0,0,0.15)',
                              display:'block', textAlign:'center',
                            }}
                          >{r.id}</span>
                        ))}
                      </div>
                    );
                  })}
                </div>
              ))}
              {/* X axis labels */}
              <div style={{ display:'flex', gap:3, marginTop:4, marginLeft:25 }}>
                {[1,2,3,4,5].map(p => (
                  <div key={p} style={{ flex:1, textAlign:'center', fontSize:11, fontWeight:700, color:'#2c3e50' }}>{p}</div>
                ))}
              </div>
              <div style={{ textAlign:'center', marginLeft:25, marginTop:4, fontSize:10, fontWeight:700, letterSpacing:2, color:'#7f8c8d', textTransform:'uppercase' }}>PROBABILIDADE</div>
            </div>
          </div>
          {/* Legend */}
          <div style={{ display:'flex', gap:12, marginTop:16, flexWrap:'wrap' }}>
            {[
              { lbl:'Crítico (≥20)', bg:'rgba(192,57,43,0.12)', border:'rgba(192,57,43,0.45)', text:'#c0392b' },
              { lbl:'Alto (≥12)', bg:'rgba(230,126,34,0.10)', border:'rgba(230,126,34,0.40)', text:'#e67e22' },
              { lbl:'Médio (≥6)', bg:'rgba(241,196,15,0.10)', border:'rgba(241,196,15,0.40)', text:'#c9a800' },
              { lbl:'Baixo (<6)', bg:'rgba(39,174,96,0.08)', border:'rgba(39,174,96,0.35)', text:'#27ae60' },
            ].map(l => (
              <div key={l.lbl} style={{ display:'flex', alignItems:'center', gap:6 }}>
                <div style={{ width:14, height:14, background:l.bg, border:'1.5px solid '+l.border, borderRadius:2 }}></div>
                <span style={{ fontSize:10, fontWeight:600, color: l.text }}>{l.lbl}</span>
              </div>
            ))}
          </div>
        </div>

        {/* TOP RISKS SIDEBAR */}
        <div>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, color:'#7f8c8d', textTransform:'uppercase', marginBottom:10, borderBottom:'1px solid #dde1e7', paddingBottom:6 }}>TOP RISCOS · P × I</div>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {[...risks].sort((a,b) => b.score - a.score).map((r, idx) => (
              <div
                key={r.id}
                onClick={() => setSelected(r)}
                style={{
                  display:'flex', alignItems:'center', gap:8, padding:'7px 10px',
                  background:'#fff', border:'1px solid #dde1e7', borderRadius:5,
                  cursor:'pointer', transition:'border-color 0.15s, box-shadow 0.15s',
                  borderLeft: '3px solid ' + (r.score>=20 ? '#c0392b' : r.score>=12 ? '#e67e22' : r.score>=6 ? '#d4aa00' : '#27ae60'),
                }}
              >
                <span style={{ fontSize:10, color:'#7f8c8d', fontWeight:700, minWidth:14, fontFamily:"'Courier New',monospace" }}>#{idx+1}</span>
                <span style={{ fontSize:10, fontWeight:700, color:'#2c3e50', fontFamily:"'Courier New',monospace", minWidth:30 }}>{r.id}</span>
                <span style={{ flex:1, fontSize:10, color:'#2c3e50', lineHeight:1.3, overflow:'hidden', display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical' as 'vertical' }}>{r.title}</span>
                <span style={{
                  fontSize:11, fontWeight:700, minWidth:24, textAlign:'center',
                  color: r.score>=20 ? '#c0392b' : r.score>=12 ? '#e67e22' : r.score>=6 ? '#c9a800' : '#27ae60',
                  fontFamily:"'Courier New',monospace"
                }}>{r.score}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* RISK DETAIL MODAL */}
      {selected && (
        <div
          onClick={() => setSelected(null)}
          style={{
            position:'fixed', inset:0, background:'rgba(26,26,46,0.55)', zIndex:1000,
            display:'flex', alignItems:'flex-end', justifyContent:'center',
            backdropFilter:'blur(2px)',
          }}
        >
          <div
            onClick={e => e.stopPropagation()}
            style={{
              background:'#fff', width:'100%', maxWidth:600, borderRadius:'10px 10px 0 0',
              padding:28, boxShadow:'0 -8px 40px rgba(0,0,0,0.18)',
              animation:'slideUp 0.25s ease-out',
              borderTop: '3px solid ' + (selected.score>=20 ? '#c0392b' : selected.score>=12 ? '#e67e22' : selected.score>=6 ? '#d4aa00' : '#27ae60'),
            }}
          >
            {/* Modal header */}
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:14 }}>
              <div>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                  <span style={{ fontSize:11, fontWeight:700, fontFamily:"'Courier New',monospace", background: selected.score>=20 ? '#c0392b' : selected.score>=12 ? '#e67e22' : '#d4aa00', color:'#fff', padding:'2px 8px', borderRadius:3, letterSpacing:1 }}>{selected.id}</span>
                  <span style={{ fontSize:9, fontWeight:700, letterSpacing:2, color:'#7f8c8d', textTransform:'uppercase' }}>{selected.cat}</span>
                </div>
                <h3 style={{ margin:0, fontSize:16, fontWeight:700, color:'#1a1a2e', fontStyle:'italic', fontFamily:"'Georgia',serif" }}>{selected.title}</h3>
              </div>
              <button onClick={() => setSelected(null)} style={{ background:'none', border:'none', fontSize:20, cursor:'pointer', color:'#7f8c8d', lineHeight:1, padding:0 }}>×</button>
            </div>
            {/* Desc */}
            <p style={{ margin:'0 0 14px', fontSize:13, color:'#2c3e50', borderLeft:'3px solid #2980b9', paddingLeft:12, lineHeight:1.6 }}>{selected.desc}</p>
            {/* Metrics */}
            <div style={{ display:'flex', gap:10 }}>
              {[
                { lbl:'PROBABILIDADE', val: String(selected.p), clr:'#2980b9' },
                { lbl:'IMPACTO', val: String(selected.i), clr:'#2980b9' },
                { lbl:'SCORE P×I', val: String(selected.score), clr: selected.score>=20 ? '#c0392b' : selected.score>=12 ? '#e67e22' : '#27ae60' },
                { lbl:'PRAZO', val: selected.deadline, clr:'#2c3e50' },
                { lbl:'STATUS', val: (statusLabel[selected.status]||selected.status), clr: statusColor[selected.status]||'#2c3e50' },
              ].map(m => (
                <div key={m.lbl} style={{ flex:1, textAlign:'center', background:'#f0f2f5', borderRadius:5, padding:'8px 6px', border:'1px solid #dde1e7' }}>
                  <div style={{ fontSize:15, fontWeight:300, color: m.clr, lineHeight:1, fontFamily:"'Courier New',monospace" }}>{m.val}</div>
                  <div style={{ fontSize:8, fontWeight:700, letterSpacing:1.5, color:'#7f8c8d', marginTop:3, textTransform:'uppercase' }}>{m.lbl}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      <style>{`@keyframes slideUp { from { transform: translateY(60px); opacity:0; } to { transform: translateY(0); opacity:1; } }`}</style>
    </section>
  );
};

export const ActionPlan = () => {
  const actions = [
    { who: 'Félix', what: 'PO Pele de Vidro — ESCALAR: Orçamento enviado segunda e sem resposta.', when: 'HOJE', priority: 'urgent' },
    { who: 'Suprimentos', what: 'Contrato CK Divisórias HPL — FECHAR: 2ª semana sem contrato.', when: '18/04', priority: 'urgent' },
    { who: 'Isaac', what: 'Clipper para rasgo de piso — CONTRATAR HOJE: Equipamento necessário.', when: 'HOJE', priority: 'high' },
    { who: 'Gestão', what: 'Notificar IZIKON formalmente: 2ª semana sem execução da ação.', when: '18/04', priority: 'high' },
  ];

  return (
    <div className="section-card">
      <h2 className="text-base font-black flex items-center gap-2 mb-6 text-slate-800 uppercase tracking-widest">
        <ListTodo className="text-mensura-blue w-5 h-5" /> Plano de Ação 
      </h2>
      <div className="space-y-2.5">
        {actions.map((action, idx) => (
          <motion.div 
            key={idx} 
            whileHover={{ x: 4 }}
            className={`flex flex-col md:flex-row gap-3 p-3.5 rounded-xl border-l-4 shadow-sm ${
              action.priority === 'urgent' ? 'bg-red-50/50 border-mensura-red' : 'bg-orange-50/50 border-mensura-orange'
            }`}
          >
            <div className="w-full md:w-32 font-black text-slate-900 border-b md:border-b-0 md:border-r border-slate-200/50 pb-1.5 md:pb-0 text-xs">{action.who}</div>
            <div className="flex-grow text-[11px] font-bold text-slate-700 leading-normal">{action.what}</div>
            <div className="w-full md:w-20 text-right font-black text-[9px] text-slate-400 uppercase self-end md:self-center bg-white/50 px-2 py-1 rounded border border-slate-100">{action.when}</div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

// --- Look Ahead Section ---
export const LookAhead = () => (
  <div className="section-card">
    <h2 className="text-base font-black flex items-center gap-2 mb-6 text-slate-800 uppercase tracking-widest">
      <GanttChartSquare className="text-mensura-blue w-5 h-5" /> Look Ahead — 3 Semanas
    </h2>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {['SEMANA 1 (16-22/04)', 'SEMANA 2 (23-29/04)', 'SEMANA 3 (30/04-06/05)'].map((week, idx) => (
        <div key={idx} className="bg-slate-50/50 rounded-2xl p-4 border border-slate-100 shadow-inner">
          <h3 className="font-black text-[10px] mb-4 text-mensura-darker border-b border-slate-200/50 pb-2 uppercase tracking-tighter flex items-center gap-2">
            <Activity className="w-3 h-3 text-mensura-blue/50" /> {week}
          </h3>
          <div className="space-y-3">
            {[
              { color: 'red', text: 'Aprovação PO Pele Vidro' },
              { color: 'orange', text: 'Conclusão Esgoto Térreo' },
              { color: 'blue', text: 'Instalação Ar-Condicionado' }
            ].map((item, iIdx) => (
              <div key={iIdx} className="flex items-start gap-2.5">
                <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 animate-pulse bg-mensura-${item.color}`} />
                <p className="text-[11px] leading-tight font-bold text-slate-600 uppercase tracking-tight">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  </div>
);

// --- Weekly Comparison Table ---
export const WeeklyComparison = () => (
    <div className="section-card">
        <h2 className="text-base font-black flex items-center gap-2 mb-6 text-slate-800 uppercase tracking-widest">
            <ArrowRightLeft className="text-mensura-blue w-5 h-5" /> Comparativo Semanal
        </h2>
        <div className="overflow-hidden rounded-xl border border-slate-200">
            <table className="w-full text-left font-mono text-xs">
                <thead className="bg-slate-50">
                    <tr className="border-b border-slate-200 uppercase text-[9px] font-black text-slate-400">
                        <th className="py-2.5 px-4 font-black">Indicador</th>
                        <th className="py-2.5 px-4 font-black">Sem. 001 (09/04)</th>
                        <th className="py-2.5 px-4 font-black">Sem. 002 (15/04)</th>
                        <th className="py-2.5 px-4 font-black">Δ</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {[
                        { name: 'Avanço Executado', s1: '42,20%', s2: '45,49%', delta: '+3,29 pp', up: true },
                        { name: 'Avanço Previsto', s1: '73,72%', s2: '81,03%', delta: '+7,31 pp', up: false },
                        { name: 'Desvio', s1: '-31,52 pp', s2: '-35,54 pp', delta: '-4,02 pp', up: false },
                        { name: 'SPI', s1: '0,57', s2: '0,56', delta: '-0,01', up: false },
                    ].map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50">
                            <td className="py-2 px-4 font-bold text-slate-600">{row.name}</td>
                            <td className="py-2 px-4 text-slate-500">{row.s1}</td>
                            <td className="py-2 px-4 text-mensura-dark font-bold font-mono">{row.s2}</td>
                            <td className={`py-2 px-4 font-black ${row.up ? 'text-green-600' : 'text-red-500'}`}>{row.delta}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    </div>
);

