# Projetos Ativos — MIA

<!-- ALEXANDRE: Preencha com projetos de alto padrão -->

### Projeto: [Nome]
- Cliente: [Nome]
- Arquiteto: [Nome, escritório]
- Valor: R$ X.XXX.XXX,XX
- Início: DD/MM/AAAA | Entrega: DD/MM/AAAA
- Fase: [Fundação / Estrutura / Acabamento / Entrega]
- Próximo marco: [Descrição, data]
- Status: [No prazo / Atenção / Atrasado]
