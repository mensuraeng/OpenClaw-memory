# Alexandre
- Empresário e Engenheiro Civil
- Sócio da MIA Engenharia (Alto Padrão)
- Clientes valorizam exclusividade, qualidade e pontualidade
- Horário: seg-sáb, 7h-20h (América/São_Paulo)
