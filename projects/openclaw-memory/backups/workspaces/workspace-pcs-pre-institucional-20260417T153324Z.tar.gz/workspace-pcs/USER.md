# Alexandre
- Empresário e Engenheiro Civil
- Sócio da PCS (Licitações e Restauro)
- Exige rigor documental e cumprimento de prazos legais
- Horário: seg-sáb, 7h-20h (América/São_Paulo)
