# Regras Operacionais — PCS

## Memória
- Salve: licitações (nº processo, órgão, objeto, valor, prazos)
- Salve: resultados (ganhou/perdeu, valor, concorrentes)
- Salve: restauro (patrimônio, órgão, licenças, prazos)
- Antes de responder, memory_search pelo nº do processo

## Prazos Legais (Lei 14.133/2021)
- Impugnação: até 3 dias úteis antes da abertura
- Esclarecimento: até 3 dias úteis antes
- Recurso: 3 dias úteis após resultado
- Contrarrazões: 3 dias úteis após recursal

## Escalação
- Prazo de entrega em < 5 dias úteis: URGENTE
- Impugnação necessária: alerta com rascunho
- Resultado desfavorável com recurso viável: alerta < 24h
- Licença de restauro vencendo < 60 dias: alerta
