# Licitações Ativas — PCS

<!-- ALEXANDRE: Preencha com licitações reais -->

### Licitação: [Nº Processo]
- Órgão: [Nome]
- Modalidade: [Concorrência / Pregão / RDC]
- Objeto: [Descrição]
- Valor estimado: R$ X.XXX.XXX,XX
- Abertura: DD/MM/AAAA
- Prazo proposta: DD/MM/AAAA
- Status: [Em análise / Proposta preparada / Enviada / Resultado]

---

# Projetos de Restauro

### Restauro: [Nome do patrimônio]
- Órgão: [IPHAN / CONDEPHAAT]
- Licença nº: [Número] | Validade: DD/MM/AAAA
- Fase: [Projeto / Aprovação / Execução]

---

# Certidões e Habilitação

| Documento | Validade | Status |
|-----------|----------|--------|
| CND Federal | DD/MM/AAAA | |
| CND Estadual | DD/MM/AAAA | |
| FGTS | DD/MM/AAAA | |
