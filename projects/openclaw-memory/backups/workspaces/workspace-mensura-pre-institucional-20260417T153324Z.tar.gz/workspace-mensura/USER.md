# Alexandre
- Empresário e Engenheiro Civil
- Sócio da Mensura (Gerenciamento de Obras), MIA (Alto Padrão), PCS (Licitações/Restauro)
- Prefere comunicação direta, sem rodeios
- Toma decisões rápidas quando tem dados
- Horário: seg-sáb, 7h-20h (América/São_Paulo)
