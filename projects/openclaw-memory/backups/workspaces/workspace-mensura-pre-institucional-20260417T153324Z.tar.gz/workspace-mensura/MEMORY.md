# Projetos Ativos — Mensura

<!-- ============================================================ -->
<!-- ALEXANDRE: PREENCHA COM SEUS PROJETOS REAIS                   -->
<!-- Este é o passo MAIS IMPORTANTE de toda a implantação.         -->
<!-- Sem dados aqui, os crons vão responder "nada encontrado".     -->
<!-- Reserve 1-2 horas para preencher.                             -->
<!-- ============================================================ -->

## Modelo (copie para cada projeto ativo)

### Projeto: [Nome]
- Contratante: [Nome]
- Contrato nº: [Número]
- Valor: R$ X.XXX.XXX,XX
- Início: DD/MM/AAAA | Prazo: DD/MM/AAAA
- Próxima medição: DD/MM/AAAA (nº X)
- SPI: [X.XX] | CPI: [X.XX]
- Fiscal: [Nome, contato]
- Status: [Em andamento / Em medição / Paralisado]

---

# Regras de Medição
- Mensais, dias 20-25
- Docs: boletim, memória de cálculo, fotos, diário de obra
- Fluxo: fiscal → gerente → pagamento (30 dias)
